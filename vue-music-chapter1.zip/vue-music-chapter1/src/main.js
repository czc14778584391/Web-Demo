import 'babel-polyfill'
import Vue from 'vue'
import App from './App'
import router from './router'
// 导入router
import fastclick from 'fastclick'
import 'common/stylus/index.styl'
import vueLazyload from 'vue-lazyload'
import store from './store'
// 全局引入store
fastclick.attach(document.body)
// 解决移动端点击300ms延迟
Vue.use(vueLazyload, {
  loading: require('common/image/default.png')
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  render: h => h(App)
})
