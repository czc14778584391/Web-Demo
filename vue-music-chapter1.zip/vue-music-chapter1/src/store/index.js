import Vue from 'vue'
import Vuex from 'vuex'
import * as getters from './getters'
import * as actions from './actions'
import state from './state'
import mutations from './mutations'
import createLogger from 'vuex/dist/logger'  // 打印mutation赋值记录

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'
// 开发模式开启打印赋值记录，会有性能消耗，上线前需要关闭
export default new Vuex.Store({
  actions,
  getters,
  state,
  mutations,
  strict: debug,
  plugins: debug ? [createLogger()] : []
})