<template>
  <div id="app">
    <m-header></m-header>
    <tab></tab>
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    <play></play>
  </div>
</template>

<script type="text/ecmascript-6">
import MHeader from 'components/m-header/m-header'
import Tab from 'components/tab/tab'
import Play from 'components/player/player'
export default {
  components: {
    MHeader,
    Tab,
    Play
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus"></style>